#! /bin/bash

./autogen.sh
./configure ./configure --enable-static --disable-shared --prefix=/home/wangyan/project/third_party/sodium

make && make check
#make install


