#! /bin/bash

set -x

scons platform=linux-gcc
rm -rf output
mkdir -p output/lib

cp -rf include output


cp libs/linux-gcc*/libjson_linux-gcc-*_libmt.a  ./
mv libjson_linux-gcc-*_libmt.a output/lib/libjson.a
cp version output


