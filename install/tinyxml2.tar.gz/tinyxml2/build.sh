#! /bin/bash

make clean;make

mkdir -p ./output/include
mkdir -p ./output/lib

cp tinyxml2.h ./output/include
cp libtinyxml.a ./output/lib

