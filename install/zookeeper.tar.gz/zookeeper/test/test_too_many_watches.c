#include <zookeeper.h>
#include<signal.h> 

#define BUF_LEN 256
#define PATH_LEN 1024
#define LONG_PATH_LEN 512

#define ZOO_GET 1
#define ZOO_SET 2
#define ZOO_CREATE 3
#define ZOO_DELETE 4

/*
char *zkServers = "jx-hadoop-rd102.jx.baidu.com:9832,\
                   jx-hadoop-rd103.jx.baidu.com:9832,\
                   jx-hadoop-rd104.jx.baidu.com:9832";
//*/

//*
char *zkServers = "jx-hadoop-rd101.jx.baidu.com:7654,\
                   jx-hadoop-rd101.jx.baidu.com:7653,\
                   jx-hadoop-rd101.jx.baidu.com:7652";
//*/
char *zooLogPath ="./zoo.log";
int zooLogLevel = ZOO_LOG_LEVEL_DEBUG;
int sessionTimeout = 30000; //30s
char *testDir = "/test_too_many_watches";
char longPath[LONG_PATH_LEN];
int pathCnt = 1000;

zhandle_t *zh;

int createPaths() {
    printf("creating tmp paths.\n");
    char path[PATH_LEN];
    char newPath[PATH_LEN];
    int pathLen = PATH_LEN;

    int zrc = zoo_create(zh, testDir, "", 0, &ZOO_OPEN_ACL_UNSAFE, 0, newPath, pathLen);
    if (ZOK != zrc) {
        fprintf(stderr, "failed to create %s err: %s\n", testDir, zerror(zrc));
        return zrc;
    }

    sprintf(path, "%s/%s", testDir, longPath);
    zrc = zoo_create(zh, path, "", 0, &ZOO_OPEN_ACL_UNSAFE, 0, newPath, pathLen);
    if (ZOK != zrc) {
        fprintf(stderr, "failed to create %s err: %s\n", path, zerror(zrc));
        return zrc;
    }

    int i;
    for (i = 0; i < pathCnt; i++) {
        sprintf(path, "%s/%s/%d", testDir, longPath, i);
        zrc = zoo_create(zh, path, "", 0, &ZOO_OPEN_ACL_UNSAFE, 0, newPath, pathLen);
        if (ZOK != zrc) {
            fprintf(stderr, "failed to create %s err: %s\n", path, zerror(zrc));
            return zrc;
        }
    }
    printf("creating tmp paths. done.\n");
    return 0;
}

void deletePaths() {
    printf("deleting tmp paths.\n");
    char path[PATH_LEN];
    int i;
    int zrc;
    for (i = 0; i < pathCnt; i++) {
        sprintf(path, "%s/%s/%d", testDir, longPath, i);
        zrc = zoo_delete(zh, path, -1);
        if (ZOK != zrc) {
            fprintf(stderr, "failed to delete %s err: %s\n", path, zerror(zrc));
        }
    }

    sprintf(path, "%s/%s", testDir, longPath);
    zrc = zoo_delete(zh, path, -1);
    if (ZOK != zrc) {
        fprintf(stderr, "failed to delete %s err: %s\n", path, zerror(zrc));
    }

    zrc = zoo_delete(zh, testDir, -1);
    if (ZOK != zrc) {
        fprintf(stderr, "failed to delete %s err: %s\n", testDir, zerror(zrc));
    }
    printf("deleting tmp paths. done.\n");
}

void testWatcher(zhandle_t *zzh, int type, int state, const char *path, void *watcherCtx) {
    //printf("watcher1 type: %d state: %d\n", type, state);
}

void testWatcher2(zhandle_t *zzh, int type, int state, const char *path, void *watcherCtx) {
    //printf("watcher2 type: %d state: %d\n", type, state);
}

void run() {
    // init
    int zrc = ZOK;

    //clientid_t clientid;
    //clientid.client_id=1212312;

    zh = zookeeper_init(zkServers, testWatcher, sessionTimeout, 0, 0, 0);
    //zh = zookeeper_init(zkServers, testWatcher, sessionTimeout, &clientid, 0, 0);
    if (NULL == zh) {
        fprintf(stderr, "failed to init zk handle.\n");
        return;
    }

    memset(longPath, 'l', LONG_PATH_LEN);
    longPath[LONG_PATH_LEN - 1] = 0;

    int ret = createPaths();
    if (ret) {
        fprintf(stderr, "failed to create paths.\n");
        deletePaths();
        return;
    }

    struct Stat stat;
    int i;

    printf("adding watches.\n");
    for (i = 0; i < pathCnt; i++) {
        char path[PATH_LEN];
        sprintf(path, "%s/%s/%d", testDir, longPath, i);
        char buf[BUF_LEN];
        int bufLen = BUF_LEN;
        zrc = zoo_wget(zh, path, testWatcher2, 0, buf, &bufLen, &stat);
        if (ZOK != zrc) {
            fprintf(stderr, "failed to get %s err: %s\n", path, zerror(zrc));
        }
        struct String_vector str_vec = {0, NULL};
        zrc = zoo_wget_children(zh, path, testWatcher2, 0, &str_vec);
        if (ZOK != zrc) {
            fprintf(stderr, "failed to get children %s err: %s\n", path, zerror(zrc));
        }
        sprintf(path, "%s/%s/%d/%d", testDir, longPath, i, i);
        zrc = zoo_wexists(zh, path, testWatcher2, 0, &stat);
    }
    printf("adding watches. done.\n");

    sleep(2000);

    deletePaths();
    zrc = zookeeper_close(zh);
}


void ctrlhandler( int a )  
{  
 printf("quit\n");  
 deletePaths();
 exit(0);  
}

int main(int argc, char **argv) {

    FILE *zooLogFile = NULL;
    zooLogFile = fopen(zooLogPath, "a");
    if (NULL == zooLogFile) {
        fprintf(stderr, "failed to open log file. %s\n", zooLogPath);
        return 2;
    }
    zoo_set_log_stream(zooLogFile);
    zoo_set_debug_level(zooLogLevel);

    signal(SIGINT,ctrlhandler); 

    run();

    fclose(zooLogFile);
    return 0;
}
