#!/bin/bash

valgrind  --tool=memcheck --leak-check=full ./test_mem_leak_repeat_add_watch_z1242

# Testing patch 1007 need to edit zk client source code.
# zookeeper.c 1950 add 'sleep(2)':
#     completion_list_t *cptr = dequeue_completion(&zh->sent_requests);
#     sleep(2);
valgrind  --tool=memcheck --leak-check=full ./test_mem_leak_iarchive_input_buffer_z1007
