#include <zookeeper.h>
#include <stdlib.h>

#define BUF_LEN 1024

char buf[BUF_LEN];

void my_watcher(zhandle_t *zh, int type, int state, const char *path,void *watcherCtx) {
    printf("%s %d\n", path, type);
    struct Stat stat;
    int buf_len = BUF_LEN;
    int zerr = zoo_wget(zh, path, my_watcher, (void *)"my_watcher", buf, &buf_len, &stat);
    printf("my_watcher zoo_get: %s\n", zerror(zerr));
}

int main() {
    const char * host = "jx-hadoop-rd102.jx.baidu.com:9832";

    zhandle_t *zh = zookeeper_init(host, NULL, 300, 0, (void *)"my_watcher", 0);
    if (NULL == zh) {
        printf("Init failed.\n");
        exit(1);
    }

    int buf_len = BUF_LEN;
    struct Stat stat;
    int zerr = zoo_wget(zh, "/a1", my_watcher, (void *)"my_watcher", buf, &buf_len, &stat);
    printf("zoo_get: %s\n", zerror(zerr));
    if (ZOK != zerr) {
        zookeeper_close(zh);
        exit(1);
    }
        
    sleep(2);

    zookeeper_close(zh);
    return 0;
}
