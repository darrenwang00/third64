#! /bin/bash

rm scons-2.3.0 -rf
tar -zxvf scons-2.3.0.tar.gz

cd scons-2.3.0

python setup.py install

export MYSCONS=`pwd`

export SCONS_LIB_DIR=$MYSCONS/engine

cd ..

rm jsoncpp-src-0.6.0-rc2 -rf

tar -zxvf jsoncpp-src-0.6.0-rc2.tar.gz

cd jsoncpp-src-0.6.0-rc2
sed -i '122s/-Wall/& -fPIC/' SConstruct

python $MYSCONS/script/scons platform=linux-gcc

cd ..

mkdir output/lib -p

cp -r jsoncpp-src-0.6.0-rc2/include/ output/
cp jsoncpp-src-0.6.0-rc2/libs/linux-gcc*/libjson_*.a output/lib/libjson.a -rf
